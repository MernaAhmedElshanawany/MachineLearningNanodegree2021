import sys
from importing_resources import *
from process_image import process_image
from tensorflow.keras.models import load_model
import json 
import argparse

parser = argparse.ArgumentParser ()
parser.add_argument ('image_path', type = str)
parser.add_argument('model', type=str)
parser.add_argument ('--top_k', default = 1, type = int)
parser.add_argument ('--category_names' , default = '', type = str)
commands = parser.parse_args()

image_path, model, top_k, class_label_map1 = commands.image_path, commands.model, commands.top_k, commands.category_names  

#Ref: https://docs.python.org/3/howto/argparse.html
    
def predict(image_path, model, top_k):
    model1= tf.keras.models.load_model(model, custom_objects={'KerasLayer':hub.KerasLayer}, compile=False)
    
#Ref: https://stackoverflow.com/questions/53368717/loading-keras-model-keyerror-weighted-metrics  

    raw_image1 = Image.open(image_path)
    raw_image = np.asarray(raw_image1)
    processed_image = process_image(raw_image)
    image_final = np.expand_dims(processed_image, axis=0)
    
    
    predicts = model1.predict(image_final)
    top_k_values, top_k_indices = tf.nn.top_k(predicts, k=top_k)
    
    top_k_values = top_k_values.numpy()
    top_k_indices = top_k_indices.numpy()
   
       
    
    print("The class(es) is/are : ",top_k_indices)
    print("and its probability is : ",top_k_values)
    
    if class_label_map1 != '':
        with open(class_label_map1) as f:
            class_names = json.load(f)
        flower_classes = []
        for x in top_k_indices[0]:
            flower_classes.append(class_names[str(x+1)])  
            
        print("The suspected flower(s) is/are : ",flower_classes)
        print("The final result is : ",flower_classes[0])
    
    return top_k_values, top_k_indices
    
if __name__ == "__main__":
    predict(image_path, model, top_k)  

