import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_hub as hub
from tensorflow.keras.preprocessing.image import ImageDataGenerator
    
import warnings
warnings.filterwarnings('ignore')
    
import os
import numpy as np
import json
import argparse
from PIL import Image
    
import logging
logger = tf.get_logger()
logger.setLevel(logging.ERROR)